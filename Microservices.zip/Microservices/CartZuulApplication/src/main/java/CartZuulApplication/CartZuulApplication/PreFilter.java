package CartZuulApplication.CartZuulApplication;

import javax.servlet.http.HttpServletRequest;

import com.netflix.zuul.ZuulFilter;
import com.netflix.zuul.context.RequestContext;
import com.netflix.zuul.exception.ZuulException;

public class PreFilter extends ZuulFilter {

	@Override
	public boolean shouldFilter() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public Object run() throws ZuulException {
		System.err.println("Pre-run()");
		RequestContext reqContext=RequestContext.getCurrentContext();
		HttpServletRequest hsreq=reqContext.getRequest();
		System.err.println("=============ClintInfo-------------");
		System.err.println(hsreq.getRemoteHost()+"\t"+hsreq.getMethod()+"\t"+hsreq.getRequestURI());
		return null;
	}

	@Override
	public String filterType() {
		System.err.println("PreFiler -FilterType()");
		return "pre";
	}

	@Override
	public int filterOrder() {
		System.err.println("PreFiler -filterOrder()");
		return 1;
	}

}
