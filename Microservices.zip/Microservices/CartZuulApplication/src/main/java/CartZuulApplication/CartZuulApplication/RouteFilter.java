package CartZuulApplication.CartZuulApplication;

import javax.servlet.http.HttpServletRequest;

import com.netflix.zuul.ZuulFilter;
import com.netflix.zuul.context.RequestContext;
import com.netflix.zuul.exception.ZuulException;

public class RouteFilter extends ZuulFilter {

	@Override
	public boolean shouldFilter() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public Object run() throws ZuulException {
		System.err.println("Route-run()");
		return null;
	}

	@Override
	public String filterType() {
		System.err.println("Route -FilterType()");
		return "route";
	}

	@Override
	public int filterOrder() {
		System.err.println("Route -filterOrder()");
		return 1;
	}
}
