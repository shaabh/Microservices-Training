package SpringCloudClient.SpringCloudClient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCloudClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
