package SpringCloudClient.SpringCloudClient;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RefreshScope
public class MainController {

	@Value("${SessioInfo.SessionTimeout}")
	private String sessionTimeOut;
	
	@Value("${dbCredentials.UserName}")
	private String userName;
	
	@Value("${dbCredentials.Password}")
	private String password;
	
	@RequestMapping("/getConfig")
	@ResponseBody()
	public String getConfig() {
		String config="Session TimeOut -: "+sessionTimeOut;
		config+="<BR> UserName - : "+userName;
		config+="<BR> Password - : "+password;
		
		return config;
	}
}
