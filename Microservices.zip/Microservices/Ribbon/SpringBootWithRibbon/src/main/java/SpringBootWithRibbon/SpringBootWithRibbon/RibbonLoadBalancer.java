package SpringBootWithRibbon.SpringBootWithRibbon;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;

import com.netflix.client.config.IClientConfig;
import com.netflix.loadbalancer.AvailabilityFilteringRule;
import com.netflix.loadbalancer.IPing;
import com.netflix.loadbalancer.IRule;
import com.netflix.loadbalancer.PingUrl;

public class RibbonLoadBalancer {
	
	@Autowired
	IClientConfig config;
	
	@Bean
	public IPing ribbonPing(IClientConfig config) {
		
		PingUrl purl= new PingUrl();
		System.err.println("Pinging is Going On");
		return purl;
	}
	
	@Bean
	public IRule ribbonRule(IClientConfig config) {
		
		AvailabilityFilteringRule rule=new AvailabilityFilteringRule();	
		System.err.println("Ribbon is fetching the Avilaibility Status of the Apllication");
		return rule;
	}
	

}
