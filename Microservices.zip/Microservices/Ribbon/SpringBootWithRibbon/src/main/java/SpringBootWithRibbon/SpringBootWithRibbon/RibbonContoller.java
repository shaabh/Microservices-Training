package SpringBootWithRibbon.SpringBootWithRibbon;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class RibbonContoller {

@Autowired
RestTemplate rest;

@Bean
@LoadBalanced	
public RestTemplate rest() {	
	 return new RestTemplate();
}

@GetMapping("/client/frontend")
public String getCart() {

	String response=rest.getForObject("httl://BackEndCart/show",String.class);
	
	return response;
}

@GetMapping("/")
public String health(){		
return "I Am Ok";
}

}
