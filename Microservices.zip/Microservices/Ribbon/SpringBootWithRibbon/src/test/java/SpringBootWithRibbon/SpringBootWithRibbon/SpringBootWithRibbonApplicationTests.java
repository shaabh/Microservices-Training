package SpringBootWithRibbon.SpringBootWithRibbon;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootWithRibbonApplicationTests {

	@Test
	void contextLoads() {
	}

}
