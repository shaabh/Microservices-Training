package BackEndCart.BackEndCart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackEndCartApplicationTests {

	@Test
	void contextLoads() {
	}

}
