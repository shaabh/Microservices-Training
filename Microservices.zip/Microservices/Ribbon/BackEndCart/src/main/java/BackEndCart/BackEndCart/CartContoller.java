package BackEndCart.BackEndCart;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CartContoller {

	ArrayList<String> items= new ArrayList<String>();
	
	public CartContoller() {
		items.add("Samsung");
		items.add("Xiomi");
	}
	
	@GetMapping("/")
	public String health(){		
	return "I Am Ok";
	}
	
	@RequestMapping(value="/add")
	void add(@PathVariable String itemName){
		items.add(itemName);
		System.out.println("Item Added succesfully");
	}
	
	@RequestMapping(value="/show")
	String show(){
		String item="";
		for(int i=0;i<items.size();i++){
			item+=items.get(i) +"\t\t";
		}
		return item;
	}
	@GetMapping("/backend")
	public String backend() {
		
		String serverPort= env.getProperty("local.server.port");
	    System.err.println("Server Port -: " +serverPort);
	    return "Server Port-: " +serverPort;
		
	}
	
	@Autowired
	Environment env;
}
