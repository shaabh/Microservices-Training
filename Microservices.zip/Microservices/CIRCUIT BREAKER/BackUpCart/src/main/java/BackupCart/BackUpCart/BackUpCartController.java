package BackupCart.BackUpCart;

import java.util.ArrayList;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class BackUpCartController {

ArrayList<String> items= new ArrayList<String>();
	
	public BackUpCartController() {
		items.add("Acus");
		items.add("Acer");
		items.add("Dell");
	}
	
	@RequestMapping(value="/add")
	void add(@PathVariable String itemName){
		items.add(itemName);
		System.out.println("Item Added succesfully");
	}
	
	@RequestMapping(value="/show")
	String show(){
		String item="";
		for(int i=0;i<items.size();i++){
			item+=items.get(i) +"\t\t";
		}
		return item;
	}
}
