package BackupCart.BackUpCart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackUpCartApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackUpCartApplication.class, args);
	}

}
