package BackupCart.BackUpCart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackUpCartApplicationTests {

	@Test
	void contextLoads() {
	}

}
