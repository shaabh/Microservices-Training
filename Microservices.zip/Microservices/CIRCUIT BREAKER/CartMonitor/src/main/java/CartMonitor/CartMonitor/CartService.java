package CartMonitor.CartMonitor;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@Service
public class CartService {


	@Autowired
	RestTemplate rest;
	
	ArrayList<String> items= new ArrayList<String>();
	
	public CartService() {
		items.add("TATA");
		items.add("Relience");
	}
	
	@HystrixCommand(fallbackMethod="handleFailure_Fallback")
	public String getCart() {
		System.err.println("Service is been Called");
		ResponseEntity<String> cartResponse=(ResponseEntity<String>)rest.exchange("http://localhost:8000/show",HttpMethod.GET,null,java.lang.String.class);
		return cartResponse.getBody();
	}
	
	/*  Fallback Action with Anather Method
	public String handleFailure_Fallback() {
		String item="Data From back Up server";
		System.err.println("Call back Fucntion Called-:");
//		for(int i=0;i<items.size();i++){
//			item+=items.get(i) +"\t\t";
//		}
		return items.toString();
	}*/
	
	
	//Fallback Action with Anather Microservice
	public String handleFailure_Fallback() {
		String item="Data From back Up server";
		System.err.println("Calling the BackUp Service");
		ResponseEntity<String> cartResponse=(ResponseEntity<String>)rest.exchange("http://localhost:8002/backUpShow",HttpMethod.GET,null,java.lang.String.class);
		return cartResponse.getBody();
	}
	
	@Bean
	public RestTemplate rest() {
		return new RestTemplate();
	}
}
