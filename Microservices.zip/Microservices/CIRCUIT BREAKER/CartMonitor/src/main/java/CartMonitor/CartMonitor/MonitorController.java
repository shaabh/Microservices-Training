package CartMonitor.CartMonitor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MonitorController {
	@Autowired
	CartService cartSevice;
	
	@RequestMapping(value="/get")
	public String getCart() {
		String cartItems=cartSevice.getCart();
		
		return cartItems;		
	}

}
