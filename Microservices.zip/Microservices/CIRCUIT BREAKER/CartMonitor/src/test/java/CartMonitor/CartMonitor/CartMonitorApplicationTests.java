package CartMonitor.CartMonitor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CartMonitorApplicationTests {

	@Test
	void contextLoads() {
	}

}
