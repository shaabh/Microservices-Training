package ZipkinClient11.ZipkinClient11;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZipkinClient11Application {

	public static void main(String[] args) {
		SpringApplication.run(ZipkinClient11Application.class, args);
	}

}
