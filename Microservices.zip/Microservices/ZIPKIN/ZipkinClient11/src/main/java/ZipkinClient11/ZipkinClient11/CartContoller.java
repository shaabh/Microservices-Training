package ZipkinClient11.ZipkinClient11;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class CartContoller {

	
	@Autowired
	RestTemplate rest;
	
	@Bean
	public RestTemplate rest() {
		return new RestTemplate();
	}
	/* Not Working
	public AlwaysSampler alwaysSampler() {
		return new AlwaysSampler();
	}*/
	
	@RequestMapping(value="/reg")
	public String register() {
		ParameterizedTypeReference<String> params= new ParameterizedTypeReference<String>() {};		
		
		ResponseEntity<String> zipkinResponse=(ResponseEntity<String>)rest.exchange("http://localhost:9411/zipkin", HttpMethod.GET,null,params);
		return zipkinResponse.getBody();
	}
	
}
