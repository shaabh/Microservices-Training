package ZipkinClient22.ZipkinClient22;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZipkinClient22Application {

	public static void main(String[] args) {
		SpringApplication.run(ZipkinClient22Application.class, args);
	}

}
