package DBConfigClient.DBConfigClient;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RefreshScope
@RestController
public class PropertyController {

	@Value("${HostName}")
	public String hostName;
	
	@Value("${port}")
	public String port;
	
	@Value("${MaxLogins}")
	public String maxLogins;
	
	@RequestMapping(value="/props")
	public String getProps() {
		 String res="Host Name -" +hostName;
		 res+="\tPort- "+ port;
		 res+="\tNo Of Faild Attempts- "+maxLogins;
		 
		 return res;
		
	}
	
}
