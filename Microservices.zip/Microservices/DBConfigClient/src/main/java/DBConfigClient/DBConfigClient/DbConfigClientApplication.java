package DBConfigClient.DBConfigClient;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.core.env.Environment;

@SpringBootApplication
public class DbConfigClientApplication {
	
	@Autowired
	public void setEnv(Environment e) {
		
		System.err.println("Host Name -: "+e.getProperty("HostName"));
		System.err.println("Port -: "+e.getProperty("port"));
		System.err.println("Max Logins -: "+e.getProperty("MaxLogins"));
	}

	public static void main(String[] args) {
		SpringApplication.run(DbConfigClientApplication.class, args);
	}
	
	

}
