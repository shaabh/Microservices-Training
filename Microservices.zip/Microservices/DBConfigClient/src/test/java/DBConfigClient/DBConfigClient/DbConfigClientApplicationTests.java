package DBConfigClient.DBConfigClient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DbConfigClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
