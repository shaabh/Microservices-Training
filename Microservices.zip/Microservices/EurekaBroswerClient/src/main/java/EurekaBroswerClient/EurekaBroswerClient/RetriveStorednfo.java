package EurekaBroswerClient.EurekaBroswerClient;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class RetriveStorednfo {
	
@Autowired
RestTemplate rest;


@RequestMapping(value="/get")
public String getAllStores(){
	
	ResponseEntity<String> entity=(ResponseEntity<String>)rest.exchange("http://Client1/info", HttpMethod.GET,null,java.lang.String.class);
	String response=entity.getBody();
	return response;
}

@Bean
@LoadBalanced
public RestTemplate rest() {
	System.out.println("Rest Teamplate is Created");
	
	return new RestTemplate();
 }
}
