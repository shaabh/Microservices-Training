package SpringEurekaServer.SpringEurekaServer;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class StoreInfo {
	
@RequestMapping(value="/info")
public String getStoreInfo() {
	
	return "Mumbai,Pune,Mysore,Kolkata,Chandigarh,Patna";
}
}
